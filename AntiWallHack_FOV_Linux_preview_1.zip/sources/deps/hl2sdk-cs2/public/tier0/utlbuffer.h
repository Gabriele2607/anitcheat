//====== Copyright © 1996-2005, Valve Corporation, All rights reserved. =======//
//
// Purpose: 
//
// $NoKeywords: $
//
// Serialization/unserialization buffer
//=============================================================================//

#ifndef UTLBUFFER_H
#define UTLBUFFER_H

#ifdef _WIN32
#pragma once
#endif

#include "platform.h"
#include "tier0/cbyteswap.h"
#include "tier0/buffer_string.h"
#include "tier0/utlleanvector.h"
#include "tier0/tier0_strtools.h"
#include <stdarg.h>


//-----------------------------------------------------------------------------
// Forward declarations
//-----------------------------------------------------------------------------
struct characterset_t;

	
//-----------------------------------------------------------------------------
// Macro to set overflow functions easily
//-----------------------------------------------------------------------------
#define SetUtlBufferOverflowFuncs( _get, _put )	\
	SetOverflowFuncs( static_cast <UtlBufferOverflowFunc_t>( _get ), static_cast <UtlBufferOverflowFunc_t>( _put ) )



template < class A >
static const char *GetFmtStr( int nRadix = 10, bool bPrint = true ) { Assert( 0 ); return ""; }

template <> inline const char *GetFmtStr< short >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return "%hd"; }
template <> inline const char *GetFmtStr< uint16 >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return "%hu"; }
template <> inline const char *GetFmtStr< int >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return "%d"; }
template <> inline const char *GetFmtStr< uint >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 || nRadix == 16 ); return nRadix == 16 ? "%x" : "%u"; }
template <> inline const char *GetFmtStr< int64 >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return "%lld"; }
template <> inline const char *GetFmtStr< float >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return "%f"; }
template <> inline const char *GetFmtStr< double >	( int nRadix, bool bPrint ) { Assert( nRadix == 10 ); return bPrint ? "%.15lf" : "%lf"; } // force Printf to print DBL_DIG=15 digits of precision for doubles - defaults to FLT_DIG=6


//-----------------------------------------------------------------------------
// Command parsing..
//-----------------------------------------------------------------------------
class CUtlBuffer
{
// Brian has on his todo list to revisit this as there are issues in some cases with CUtlVector using operator = instead of copy construtor in InsertMultiple, etc.
// The unsafe case is something like this:
//  CUtlVector< CUtlBuffer > vecFoo;
// 
//  CUtlBuffer buf;
//  buf.Put( xxx );
//  vecFoo.Insert( buf );
//
//  This will cause memory corruption when vecFoo is cleared
//
//private:
//	// Disallow copying
//	CUtlBuffer( const CUtlBuffer & );// { Assert( 0 ); }
//	CUtlBuffer &operator=( const CUtlBuffer & );//  { Assert( 0 ); return *this; }

public:
	enum SeekType_t
	{
		SEEK_HEAD = 0,
		SEEK_CURRENT,
		SEEK_TAIL
	};

	// flags
	enum BufferFlags_t
	{
		BF_NONE = 0,
		TEXT_BUFFER = 0x1,			// Describes how get + put work (as strings, or binary)
		EXTERNAL_GROWABLE = 0x2,	// This is used w/ external buffers and causes the utlbuf to switch to reallocatable memory if an overflow happens when Putting.
		CONTAINS_CRLF = 0x4,		// For text buffers only, does this contain \n or \n\r?
		READ_ONLY = 0x8,			// For external buffers; prevents null termination from happening.
		AUTO_TABS_DISABLED = 0x10,	// Used to disable/enable push/pop tabs
	};

	// Overflow functions when a get or put overflows
	typedef bool (CUtlBuffer::*UtlBufferOverflowFunc_t)( int nSize );

	// Constructors for growable + external buffers for serialization/unserialization
	DLL_CLASS_IMPORT CUtlBuffer( int growSize = 0, int initSize = 0, CUtlBuffer::BufferFlags_t nFlags = BufferFlags_t::BF_NONE );
	DLL_CLASS_IMPORT CUtlBuffer( const void* pBuffer, int size, CUtlBuffer::BufferFlags_t nFlags = BufferFlags_t::BF_NONE );
	// This one isn't actually defined so that we catch contructors that are trying to pass a bool in as the third param.
	CUtlBuffer( const void *pBuffer, int size, bool crap );

	unsigned char	GetFlags() const;

	// NOTE: This will assert if you attempt to recast it in a way that
	// is not compatible. The only valid conversion is binary-> text w/CRLF
	DLL_CLASS_IMPORT void		SetBufferType( bool bIsText, bool bContainsCRLF );

	// Makes sure we've got at least this much memory
	DLL_CLASS_IMPORT void		EnsureCapacity( int num );

	// Access for direct read into buffer
	void *			AccessForDirectRead( int nBytes );
	DLL_CLASS_IMPORT const void *AccessGet( int nBytes );
	DLL_CLASS_IMPORT void *AccessPut( int nBytes );

	// Attaches the buffer to external memory....
	DLL_CLASS_IMPORT void		SetExternalBuffer( void* pMemory, int nSize, int nInitialPut, CUtlBuffer::BufferFlags_t nFlags = BufferFlags_t::BF_NONE );
	bool			IsExternallyAllocated() const;
	DLL_CLASS_IMPORT void		AssumeMemory( void *pMemory, int nSize, int nInitialPut, CUtlBuffer::BufferFlags_t nFlags = BufferFlags_t::BF_NONE );
	void			*Detach();
	DLL_CLASS_IMPORT void *DetachMemory();

	FORCEINLINE void ActivateByteSwappingIfBigEndian( void )
	{
	}


	// Controls endian-ness of binary utlbufs - default matches the current platform
	DLL_CLASS_IMPORT void	ActivateByteSwapping( bool bActivate );
	DLL_CLASS_IMPORT void	SetBigEndian( bool bigEndian );
	DLL_CLASS_IMPORT bool	IsBigEndian( void );

	DLL_CLASS_IMPORT void	AlignBuffer( int alignment );
	// Skips zero bytes until the get position is aligned, returning false on a non-zero byte or the buffer's end
	DLL_CLASS_IMPORT bool	AlignBufferGet( int alignment );

	// Resets the buffer; but doesn't free memory
	void			Clear();

	// Clears out the buffer; frees memory
	void			Purge();

	// Dump the buffer to stdout
	void			Spew( );

	DLL_CLASS_IMPORT void Swap( CUtlBuffer &other );
	DLL_CLASS_IMPORT void Swap( CUtlLeanVector<unsigned char> &other );

	DLL_CLASS_IMPORT bool WriteToFile( const char *, bool );
	DLL_CLASS_IMPORT bool WriteToFileIfDifferent( const char * );

	// Read stuff out.
	// Binary mode: it'll just read the bits directly in, and characters will be
	//		read for strings until a null character is reached.
	// Text mode: it'll parse the file, turning text #s into real numbers.
	//		GetString will read a string until a space is reached
	char			GetChar( );
	unsigned char	GetUnsignedChar( );
	short			GetShort( );
	unsigned short	GetUnsignedShort( );
	int				GetInt( );
	int64			GetInt64( );
	unsigned int	GetIntHex( );
	unsigned int	GetUnsignedInt( );
	float			GetFloat( );
	double			GetDouble( );
	void *			GetPtr();
	DLL_CLASS_IMPORT void	GetString( char* pString, int nMaxChars = 0 );
	DLL_CLASS_IMPORT void	GetString( CBufferString *pString );
	DLL_CLASS_IMPORT bool	Get( void* pMem, int size );
	DLL_CLASS_IMPORT void	GetLine( char* pLine, int nMaxChars = 0 );
	DLL_CLASS_IMPORT void	GetLine( CBufferString *pLine );

	// This will get at least 1 byte and up to nSize bytes. 
	// It will return the number of bytes actually read.
	DLL_CLASS_IMPORT int	GetUpTo( void *pMem, int nSize );

	// This version of GetString converts \" to \\ and " to \, etc.
	// It also reads a " at the beginning and end of the string
	DLL_CLASS_IMPORT void	GetDelimitedString( CUtlCharConversion *pConv, char *pString, int nMaxChars = 0 );
	DLL_CLASS_IMPORT void	GetDelimitedString( CUtlCharConversion *pConv, CBufferString *pString );
	DLL_CLASS_IMPORT char	GetDelimitedChar( CUtlCharConversion *pConv );

	// This will return the # of characters of the string about to be read out
	// NOTE: The count will *include* the terminating 0!!
	// In binary mode, it's the number of characters until the next 0
	// In text mode, it's the number of characters until the next space.
	DLL_CLASS_IMPORT int	PeekStringLength();

	// This version of PeekStringLength converts \" to \\ and " to \, etc.
	// It also reads a " at the beginning and end of the string
	// NOTE: The count will *include* the terminating 0!!
	// In binary mode, it's the number of characters until the next 0
	// In text mode, it's the number of characters between "s (checking for \")
	// Specifying false for bActualSize will return the pre-translated number of characters
	// including the delimiters and the escape characters. So, \n counts as 2 characters when bActualSize == false
	// and only 1 character when bActualSize == true
	DLL_CLASS_IMPORT int	PeekDelimitedStringLength( CUtlCharConversion *pConv, bool bActualSize = true );

	// Just like scanf, but doesn't work in binary mode
	DLL_CLASS_IMPORT int	Scanf( SCANF_FORMAT_STRING const char* pFmt, ... );
	DLL_CLASS_IMPORT int	VaScanf( const char* pFmt, va_list list );

	// Eats white space, advances Get index
	DLL_CLASS_IMPORT void	EatWhiteSpace();

	// Eats C++ style comments
	DLL_CLASS_IMPORT bool	EatCPPComment();
	DLL_CLASS_IMPORT bool	EatCComment( int * );

	// (For text buffers only)
	// Parse a token from the buffer:
	// Grab all text that lies between a starting delimiter + ending delimiter
	// (skipping whitespace that leads + trails both delimiters).
	// If successful, the get index is advanced and the function returns true,
	// otherwise the index is not advanced and the function returns false.
	DLL_CLASS_IMPORT bool	ParseToken( const char *pStartingDelim, const char *pEndingDelim, char *pString, int nMaxLen );
	DLL_CLASS_IMPORT bool	ParseToken( const char *pStartingDelim, const char *pEndingDelim, CBufferString *pString );

	// Advance the get index until after the particular string is found
	// Do not eat whitespace before starting. Return false if it failed
	// String test is case-insensitive.
	DLL_CLASS_IMPORT bool	GetToken( const char *pToken );

	// Parses the next token, given a set of character breaks to stop at
	// Returns the length of the token parsed in bytes (-1 if none parsed)
	DLL_CLASS_IMPORT int	ParseToken( const characterset_t *pBreaks, char *pTokenBuf, int nMaxLen, bool bParseComments = true );
	DLL_CLASS_IMPORT int	ParseToken( const characterset_t *pBreaks, CBufferString *pTokenBuf, bool bParseComments = true );

	// Write stuff in
	// Binary mode: it'll just write the bits directly in, and strings will be
	//		written with a null terminating character
	// Text mode: it'll convert the numbers to text versions
	//		PutString will not write a terminating character
	void			PutChar( char c );
	void			PutUnsignedChar( unsigned char uc );
	void			PutShort( short s );
	void			PutUnsignedShort( unsigned short us );
	void			PutInt( int i );
	void			PutInt64( int64 i );
	void			PutUnsignedInt( unsigned int u );
	void			PutFloat( float f );
	void			PutDouble( double d );
	void			PutPtr( void * ); // Writes the pointer, not the pointed to
	DLL_CLASS_IMPORT void	PutString( const char* pString );
	DLL_CLASS_IMPORT void	Put( const void* pMem, int size );

	// This version of PutString converts \ to \\ and " to \", etc.
	// It also places " at the beginning and end of the string
	DLL_CLASS_IMPORT void	PutDelimitedString( CUtlCharConversion *pConv, const char *pString );
	DLL_CLASS_IMPORT void	PutDelimitedChar( CUtlCharConversion *pConv, char c );

	DLL_CLASS_IMPORT bool	PutFileContent( const char *pString );
	DLL_CLASS_IMPORT void	PutJSONString( const char *pString );

	DLL_CLASS_IMPORT void	PutZeros( int nCount );

	// Just like printf, writes a terminating zero in binary mode
	DLL_CLASS_IMPORT void	Printf( const char* pFmt, ... ) FMTFUNCTION( 2, 3 );
	DLL_CLASS_IMPORT void	VaPrintf( const char* pFmt, va_list list );

	// What am I writing (put)/reading (get)?
	void* PeekPut( int offset = 0 );
	const void* PeekGet( int offset = 0 ) const;
	DLL_CLASS_IMPORT const void* PeekGet( int nMaxSize, int nOffset );

	// Where am I writing (put)/reading (get)?
	int TellPut( ) const;
	int TellGet( ) const;

	// What's the most I've ever written?
	int TellMaxPut( ) const;

	// How many bytes remain to be read?
	// NOTE: This is not accurate for streaming text files; it overshoots
	int GetBytesRemaining() const;

	// Change where I'm writing (put)/reading (get)
	DLL_CLASS_IMPORT void SeekPut( SeekType_t type, int offset );
	DLL_CLASS_IMPORT void SeekGet( SeekType_t type, int offset );

	// Buffer base
	const void* Base() const;
	void* Base();

	// memory allocation size, does *not* reflect size written or read,
	//	use TellPut or TellGet for that
	int Size() const;

	// Am I a text buffer?
	bool IsText() const;

	// Can I grow if I'm externally allocated?
	bool IsGrowable() const;

	// Am I valid? (overflow or underflow error), Once invalid it stays invalid
	bool IsValid() const;

	// Do I contain carriage return/linefeeds? 
	bool ContainsCRLF() const;

	// Am I read-only
	bool IsReadOnly() const;

	// Converts a buffer from a CRLF buffer to a CR buffer (and back)
	// Returns false if no conversion was necessary (and outBuf is left untouched)
	// If the conversion occurs, outBuf will be cleared.
	DLL_CLASS_IMPORT bool ConvertCRLF( CUtlBuffer &outBuf );

	// Push/pop pretty-printing tabs
	void PushTab();
	void PopTab();

	// Temporarily disables pretty print
	void EnableTabs( bool bEnable );

protected:
	// error flags
	enum
	{
		PUT_OVERFLOW = 0x1,
		GET_OVERFLOW = 0x2,
		MAX_ERROR_FLAG = GET_OVERFLOW,
	};

	DLL_CLASS_IMPORT void SetOverflowFuncs( UtlBufferOverflowFunc_t getFunc, UtlBufferOverflowFunc_t putFunc );

	DLL_CLASS_IMPORT bool OnPutOverflow( int nSize );
	DLL_CLASS_IMPORT bool OnGetOverflow( int nSize );

protected:
	// Checks if a get/put is ok
	DLL_CLASS_IMPORT bool CheckPut( int size );
	DLL_CLASS_IMPORT bool CheckGet( int size );

	DLL_CLASS_IMPORT void AddNullTermination( );

	// Methods to help with pretty-printing
	bool WasLastCharacterCR();
	void PutTabs();

	// Help with delimited stuff
	DLL_CLASS_IMPORT char GetDelimitedCharInternal( CUtlCharConversion *pConv );
	DLL_CLASS_IMPORT void PutDelimitedCharInternal( CUtlCharConversion *pConv, char c );

	// Default overflow funcs
	DLL_CLASS_IMPORT bool PutOverflow( int nSize );
	DLL_CLASS_IMPORT bool GetOverflow( int nSize );

	// Does the next bytes of the buffer match a pattern?
	DLL_CLASS_IMPORT bool	PeekStringMatch( int nOffset, const char *pString, int nLen );

	// Peek size of line to come, check memory bound
	DLL_CLASS_IMPORT int	PeekLineLength();

	// How much whitespace should I skip?
	DLL_CLASS_IMPORT int	PeekWhiteSpace( int nOffset );

	// Checks if a peek get is ok
	DLL_CLASS_IMPORT bool	CheckPeekGet( int nOffset, int nSize );

public:
	// Call this to peek arbitrarily long into memory. It doesn't fail unless
	// it can't read *anything* new
	DLL_CLASS_IMPORT bool	CheckArbitraryPeekGet( int nOffset, int &nIncrement );

protected:

	template <typename T> void GetType( T& dest );
	template <typename T> void GetTypeBin( T& dest );
	template <typename T> bool GetTypeText( T &value, int nRadix = 10 );

	template <typename T> void PutType( T src );
	template <typename T> void PutTypeBin( T src );

	CUtlLeanVector<unsigned char> m_Memory;
	int m_Get;
	int m_Put;

	unsigned char m_Error;
	unsigned char m_Flags;
	unsigned char m_Reserved;

	int m_nTab;
	int m_nMaxPut;
	int m_nOffset;

	UtlBufferOverflowFunc_t m_GetOverflowFunc;
	UtlBufferOverflowFunc_t m_PutOverflowFunc;

	CByteswap	m_Byteswap;
};

constexpr CUtlBuffer::BufferFlags_t operator|( const CUtlBuffer::BufferFlags_t f, const CUtlBuffer::BufferFlags_t v )
{
	return static_cast<CUtlBuffer::BufferFlags_t>(static_cast<int>(f) | static_cast<int>(v));
}

// Stream style output operators for CUtlBuffer
inline CUtlBuffer &operator<<( CUtlBuffer &b, char v )
{
	b.PutChar( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, unsigned char v )
{
	b.PutUnsignedChar( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, short v )
{
	b.PutShort( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, unsigned short v )
{
	b.PutUnsignedShort( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, int v )
{
	b.PutInt( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, unsigned int v )
{
	b.PutUnsignedInt( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, float v )
{
	b.PutFloat( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, double v )
{
	b.PutDouble( v );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, const char *pv )
{
	b.PutString( pv );
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, const Vector &v )
{
	b << v.x << " " << v.y << " " << v.z;
	return b;
}

inline CUtlBuffer &operator<<( CUtlBuffer &b, const Vector2D &v )
{
	b << v.x << " " << v.y;
	return b;
}


class CUtlInplaceBuffer : public CUtlBuffer
{
public:
	DLL_CLASS_IMPORT CUtlInplaceBuffer( CUtlBuffer::BufferFlags_t nFlags = BufferFlags_t::BF_NONE );

	//
	// Routines returning buffer-inplace-pointers
	//
public:
	//
	// Upon success, determines the line length, fills out the pointer to the
	// beginning of the line and the line length, advances the "get" pointer
	// offset by the line length and returns "true".
	//
	// If end of file is reached or upon error returns "false".
	//
	// Note:	the returned length of the line is at least one character because the
	//			trailing newline characters are also included as part of the line.
	//
	// Note:	the pointer returned points into the local memory of this buffer, in
	//			case the buffer gets relocated or destroyed the pointer becomes invalid.
	//
	// e.g.:	-------------
	//
	//			char *pszLine;
	//			int nLineLen;
	//			while ( pUtlInplaceBuffer->InplaceGetLinePtr( &pszLine, &nLineLen ) )
	//			{
	//				...
	//			}
	//
	//			-------------
	//
	// @param	ppszInBufferPtr		on return points into this buffer at start of line
	// @param	pnLineLength		on return holds num bytes accessible via (*ppszInBufferPtr)
	//
	// @returns	true				if line was successfully read
	//			false				when EOF is reached or error occurs
	//
	DLL_CLASS_IMPORT bool InplaceGetLinePtr( /* out */ char **ppszInBufferPtr, /* out */ int *pnLineLength );

	//
	// Determines the line length, advances the "get" pointer offset by the line length,
	// replaces the newline character with null-terminator and returns the initial pointer
	// to now null-terminated line.
	//
	// If end of file is reached or upon error returns NULL.
	//
	// Note:	the pointer returned points into the local memory of this buffer, in
	//			case the buffer gets relocated or destroyed the pointer becomes invalid.
	//
	// e.g.:	-------------
	//
	//			while ( char *pszLine = pUtlInplaceBuffer->InplaceGetLinePtr() )
	//			{
	//				...
	//			}
	//
	//			-------------
	//
	// @returns	ptr-to-zero-terminated-line		if line was successfully read and buffer modified
	//			NULL							when EOF is reached or error occurs
	//
	DLL_CLASS_IMPORT char * InplaceGetLinePtr( void );
};


//-----------------------------------------------------------------------------
// Where am I reading?
//-----------------------------------------------------------------------------
inline int CUtlBuffer::TellGet( ) const
{
	return m_Get;
}


//-----------------------------------------------------------------------------
// How many bytes remain to be read?
//-----------------------------------------------------------------------------
inline int CUtlBuffer::GetBytesRemaining() const
{
	return m_nMaxPut - TellGet();
}


//-----------------------------------------------------------------------------
// What am I reading?
//-----------------------------------------------------------------------------
inline const void* CUtlBuffer::PeekGet( int offset ) const
{
	return &m_Memory[ m_Get + offset - m_nOffset ];
}


//-----------------------------------------------------------------------------
// Unserialization
//-----------------------------------------------------------------------------

template <typename T> 
inline void CUtlBuffer::GetTypeBin( T &dest )
{
	if ( CheckGet( sizeof(T) ) )
	{
		if ( !m_Byteswap.IsSwappingBytes() || ( sizeof( T ) == 1 ) )
		{
			dest = *(T *)PeekGet();
		}
		else
		{
			m_Byteswap.SwapBufferToTargetEndian<T>( &dest, (T*)PeekGet() );
		}
		m_Get += sizeof(T);	
	}		
	else
	{
		dest = 0;
	}					
}

template <>
inline void CUtlBuffer::GetTypeBin< float >( float &dest )
{
	if ( CheckGet( sizeof( float ) ) )
	{
		uintp pData = (uintp)PeekGet();
		dest = *(float *)pData;
		if ( m_Byteswap.IsSwappingBytes() )
		{
			m_Byteswap.SwapBufferToTargetEndian< float >( &dest, &dest );
		}
		m_Get += sizeof( float );	
	}		
	else
	{
		dest = 0;
	}					
}

template <>
inline void CUtlBuffer::GetTypeBin< double >( double &dest )
{
	if ( CheckGet( sizeof( double ) ) )
	{
		uintp pData = (uintp)PeekGet();
		dest = *(double *)pData;
		if ( m_Byteswap.IsSwappingBytes() )
		{
			m_Byteswap.SwapBufferToTargetEndian< double >( &dest, &dest );
		}
		m_Get += sizeof( double );	
	}		
	else
	{
		dest = 0;
	}					
}

template < class T >
inline T StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	Assert( 0 );
	*ppEnd = pString;
	return 0;
}

template <>
inline int8 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( int8 )strtol( pString, ppEnd, nRadix );
}

template <>
inline uint8 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( uint8 )strtoul( pString, ppEnd, nRadix );
}

template <>
inline int16 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( int16 )strtol( pString, ppEnd, nRadix );
}

template <>
inline uint16 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( uint16 )strtoul( pString, ppEnd, nRadix );
}

template <>
inline int32 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( int32 )strtol( pString, ppEnd, nRadix );
}

template <>
inline uint32 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( uint32 )strtoul( pString, ppEnd, nRadix );
}

template <>
inline int64 StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	return ( int64 )_strtoi64( pString, ppEnd, nRadix );
}

template <>
inline float StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	// /*UNUSED*/( nRadix );
	return ( float )strtod( pString, ppEnd );
}

template <>
inline double StringToNumber( char *pString, char **ppEnd, int nRadix )
{
	// /*UNUSED*/( nRadix );
	return ( double )strtod( pString, ppEnd );
}

template <typename T>
inline bool CUtlBuffer::GetTypeText( T &value, int nRadix /*= 10*/ )
{
	// NOTE: This is not bullet-proof; it assumes numbers are < 128 characters
	int nLength = 128;
	if ( !CheckArbitraryPeekGet( 0, nLength ) )
	{
		value = 0;
		return false;
	}

	char *pStart = (char*)PeekGet();
	char* pEnd = pStart;
	value = StringToNumber< T >( pStart, &pEnd, nRadix );

	int nBytesRead = (int)( pEnd - pStart );
	if ( nBytesRead == 0 )
		return false;

	m_Get += nBytesRead;
	return true;
}

template <typename T> 
inline void CUtlBuffer::GetType( T &dest )
{
	if (!IsText())
	{
		GetTypeBin( dest );
	}
	else
	{
		GetTypeText( dest );
	}
}

inline char CUtlBuffer::GetChar( )
{
	// LEGACY WARNING: this behaves differently than GetUnsignedChar()
	char c;
	GetTypeBin( c ); // always reads as binary
	return c;
}

inline unsigned char CUtlBuffer::GetUnsignedChar( )
{
	// LEGACY WARNING: this behaves differently than GetChar()
	unsigned char c;
	if (!IsText())
	{
		GetTypeBin( c );
	}
	else
	{
		c = ( unsigned char )GetUnsignedShort();
	}
	return c;
}

inline short CUtlBuffer::GetShort( )
{
	short s;
	GetType( s );
	return s;
}

inline unsigned short CUtlBuffer::GetUnsignedShort( )
{
	unsigned short s;
	GetType( s );
	return s;
}

inline int CUtlBuffer::GetInt( )
{
	int i;
	GetType( i );
	return i;
}

inline int64 CUtlBuffer::GetInt64( )
{
	int64 i;
	GetType( i );
	return i;
}

inline unsigned int CUtlBuffer::GetIntHex( )
{
	uint i;
	if (!IsText())
	{
		GetTypeBin( i );
	}
	else
	{
		GetTypeText( i, 16 );
	}
	return i;
}

inline unsigned int CUtlBuffer::GetUnsignedInt( )
{
	unsigned int i;
	GetType( i );
	return i;
}

inline float CUtlBuffer::GetFloat( )
{
	float f;
	GetType( f );
	return f;
}

inline double CUtlBuffer::GetDouble( )
{
	double d;
	GetType( d );
	return d;
}

inline void *CUtlBuffer::GetPtr( )
{
	void *p;
	// LEGACY WARNING: in text mode, PutPtr writes 32 bit pointers in hex, while GetPtr reads 32 or 64 bit pointers in decimal
#ifndef X64BITS
	p = ( void* )GetUnsignedInt();
#else
	p = ( void* )GetInt64();
#endif
	return p;
}

//-----------------------------------------------------------------------------
// Where am I writing?
//-----------------------------------------------------------------------------
inline unsigned char CUtlBuffer::GetFlags() const
{ 
	return m_Flags; 
}


//-----------------------------------------------------------------------------
// 
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::IsExternallyAllocated() const
{ 
	return m_Memory.IsExternallyAllocated();
}

	
//-----------------------------------------------------------------------------
// Where am I writing?
//-----------------------------------------------------------------------------
inline int CUtlBuffer::TellPut( ) const
{
	return m_Put;
}


//-----------------------------------------------------------------------------
// What's the most I've ever written?
//-----------------------------------------------------------------------------
inline int CUtlBuffer::TellMaxPut( ) const
{
	return m_nMaxPut;
}


//-----------------------------------------------------------------------------
// What am I reading?
//-----------------------------------------------------------------------------
inline void* CUtlBuffer::PeekPut( int offset )
{
	return &m_Memory[m_Put + offset - m_nOffset];
}


//-----------------------------------------------------------------------------
// Various put methods
//-----------------------------------------------------------------------------

template <typename T> 
inline void CUtlBuffer::PutTypeBin( T src )
{
	if ( CheckPut( sizeof(T) ) )
	{
		if ( !m_Byteswap.IsSwappingBytes() || ( sizeof( T ) == 1 ) )
		{
			*(T *)PeekPut() = src;
		}
		else
		{
			m_Byteswap.SwapBufferToTargetEndian<T>( (T*)PeekPut(), &src );
		}
		m_Put += sizeof(T);
		AddNullTermination();
	}
}

template <typename T> 
inline void CUtlBuffer::PutType( T src )
{
	if (!IsText())
	{
		PutTypeBin( src );
	}
	else
	{
		Printf( GetFmtStr< T >(), src );
	}
}

//-----------------------------------------------------------------------------
// Methods to help with pretty-printing
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::WasLastCharacterCR()
{
	if ( !IsText() || (TellPut() == 0) )
		return false;
	return ( *( const char * )PeekPut( -1 ) == '\n' );
}

inline void CUtlBuffer::PutTabs()
{
	int nTabCount = ( m_Flags & AUTO_TABS_DISABLED ) ? 0 : m_nTab;
	for (int i = nTabCount; --i >= 0; )
	{
		PutTypeBin<char>( '\t' );
	}
}


//-----------------------------------------------------------------------------
// Push/pop pretty-printing tabs
//-----------------------------------------------------------------------------
inline void CUtlBuffer::PushTab( )
{
	++m_nTab;
}

inline void CUtlBuffer::PopTab()
{
	if ( --m_nTab < 0 )
	{
		m_nTab = 0;
	}
}


//-----------------------------------------------------------------------------
// Temporarily disables pretty print
//-----------------------------------------------------------------------------
inline void CUtlBuffer::EnableTabs( bool bEnable )
{
	if ( bEnable )
	{
		m_Flags &= ~AUTO_TABS_DISABLED;
	}
	else
	{
		m_Flags |= AUTO_TABS_DISABLED; 
	}
}

inline void CUtlBuffer::PutChar( char c )
{
	if ( WasLastCharacterCR() )
	{
		PutTabs();
	}

	PutTypeBin( c );
}

inline void CUtlBuffer::PutUnsignedChar( unsigned char c )
{
	if (!IsText())
	{
		PutTypeBin( c );
	}
	else
	{
		PutUnsignedShort( c );
	}
}

inline void  CUtlBuffer::PutShort( short s )
{
	PutType( s );
}

inline void CUtlBuffer::PutUnsignedShort( unsigned short s )
{
	PutType( s );
}

inline void CUtlBuffer::PutInt( int i )
{
	PutType( i );
}

inline void CUtlBuffer::PutInt64( int64 i )
{
	PutType( i );
}

inline void CUtlBuffer::PutUnsignedInt( unsigned int u )
{
	PutType( u );
}

inline void CUtlBuffer::PutFloat( float f )
{
	PutType( f );
}

inline void CUtlBuffer::PutDouble( double d )
{
	PutType( d );
}

inline void CUtlBuffer::PutPtr( void *p )
{
	// LEGACY WARNING: in text mode, PutPtr writes 32 bit pointers in hex, while GetPtr reads 32 or 64 bit pointers in decimal
	if (!IsText())
	{
		PutTypeBin( p );
	}
	else
	{
		Printf( "0x%p", p );
	}
}

//-----------------------------------------------------------------------------
// Am I a text buffer?
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::IsText() const 
{ 
	return (m_Flags & TEXT_BUFFER) != 0; 
}


//-----------------------------------------------------------------------------
// Can I grow if I'm externally allocated?
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::IsGrowable() const 
{ 
	return (m_Flags & EXTERNAL_GROWABLE) != 0; 
}


//-----------------------------------------------------------------------------
// Am I valid? (overflow or underflow error), Once invalid it stays invalid
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::IsValid() const 
{ 
	return m_Error == 0; 
}


//-----------------------------------------------------------------------------
// Do I contain carriage return/linefeeds? 
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::ContainsCRLF() const 
{ 
	return IsText() && ((m_Flags & CONTAINS_CRLF) != 0); 
} 


//-----------------------------------------------------------------------------
// Am I read-only
//-----------------------------------------------------------------------------
inline bool CUtlBuffer::IsReadOnly() const
{
	return (m_Flags & READ_ONLY) != 0; 
}


//-----------------------------------------------------------------------------
// Buffer base and size
//-----------------------------------------------------------------------------
inline const void* CUtlBuffer::Base() const	
{ 
	return m_Memory.Base(); 
}

inline void* CUtlBuffer::Base()
{
	return m_Memory.Base(); 
}

inline int CUtlBuffer::Size() const			
{ 
	return m_Memory.NumAllocated(); 
}


//-----------------------------------------------------------------------------
// Clears out the buffer; frees memory
//-----------------------------------------------------------------------------
inline void CUtlBuffer::Clear()
{
	m_Get = 0;
	m_Put = 0;
	m_Error = 0;
	m_nOffset = 0;
	m_nMaxPut = -1;
	AddNullTermination();
}

inline void CUtlBuffer::Purge()
{
	m_Get = 0;
	m_Put = 0;
	m_nOffset = 0;
	m_nMaxPut = 0;
	m_Error = 0;
	m_Memory.Purge();
}

//-----------------------------------------------------------------------------
// 
//-----------------------------------------------------------------------------
inline void *CUtlBuffer::AccessForDirectRead( int nBytes )
{
	Assert( m_Get == 0 && m_Put == 0 && m_nMaxPut == 0 );
	EnsureCapacity( nBytes );
	m_nMaxPut = nBytes;
	return Base();
}

inline void *CUtlBuffer::Detach()
{
	void *p = m_Memory.Detach();
	Clear();
	return p;
}

//-----------------------------------------------------------------------------

inline void CUtlBuffer::Spew( )
{
	SeekGet( CUtlBuffer::SEEK_HEAD, 0 );

	char pTmpLine[1024];
	while( IsValid() && GetBytesRemaining() )
	{
		V_memset( pTmpLine, 0, sizeof(pTmpLine) );
		Get( pTmpLine, MIN( (unsigned int)GetBytesRemaining(), sizeof(pTmpLine)-1 ) );
		Msg( _T( "%s" ), pTmpLine );
	}
}


#endif // UTLBUFFER_H

