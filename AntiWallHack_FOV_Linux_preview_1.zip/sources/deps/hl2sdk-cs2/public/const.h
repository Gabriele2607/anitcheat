//========= Copyright © 1996-2005, Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//
//=============================================================================//
#ifndef CONST_H
#define CONST_H

#ifdef _WIN32
#pragma once
#endif

#include "platform.h"
#include "bitvec.h"

// the command line param that tells the engine to use steam
#define STEAM_PARM					"-steam"
// the command line param to tell dedicated server to restart 
// if they are out of date
#define AUTO_RESTART "-autoupdate"

// the message a server sends when a clients steam login is expired
#define INVALID_STEAM_TICKET "Invalid STEAM UserID Ticket\n"
#define INVALID_STEAM_LOGON "No Steam logon\n"
#define INVALID_STEAM_VACBANSTATE "VAC banned from secure server\n"
#define INVALID_STEAM_LOGGED_IN_ELSEWHERE "This Steam account is being used in another location\n"

// This is the default, see shareddefs.h for mod-specific value, which can override this
#define DEFAULT_TICK_INTERVAL	(1.0f / 60.0f)				// 16.666667 msec is the default
#define MINIMUM_TICK_INTERVAL   (0.001)
#define MAXIMUM_TICK_INTERVAL	(0.1)

// This is the max # of players the engine can handle
// Note, must be power of 2
#define ABSOLUTE_PLAYER_LIMIT 64
#define ABSOLUTE_PLAYER_LIMIT_DW	( (ABSOLUTE_PLAYER_LIMIT/32) + 1 )

#if ABSOLUTE_PLAYER_LIMIT > 32
#define CPlayerBitVec CBitVec<ABSOLUTE_PLAYER_LIMIT>
#else
#define CPlayerBitVec CDWordBitVec
#endif

// a player name may have 31 chars + 0 on the PC.
#define MAX_PLAYER_NAME_LENGTH		32

#define MAX_PLAYERS_PER_CLIENT		1	// One player per PC

#define MAX_MAP_NAME				32	
#define	MAX_NETWORKID_LENGTH		64  // num chars for a network (i.e steam) ID

// BUGBUG: Reconcile with or derive this from the engine's internal definition!
// FIXME: I added an extra bit because I needed to make it signed
#define SP_MODEL_INDEX_BITS			11

// How many bits to use to encode an edict.
#define	MAX_EDICT_BITS				14			// # of bits needed to represent max edicts
// Max # of edicts in a level
#define	MAX_EDICTS					(1<<MAX_EDICT_BITS)

// How many bits to use to encode an server class index
#define MAX_SERVER_CLASS_BITS		9
// Max # of networkable server classes
#define MAX_SERVER_CLASSES			(1<<MAX_SERVER_CLASS_BITS)

#define SIGNED_GUID_LEN 32 // Hashed CD Key (32 hex alphabetic chars + 0 terminator )

// Used for networking ehandles.
#define NUM_ENT_ENTRY_BITS		(MAX_EDICT_BITS + 2)
#define NUM_ENT_ENTRIES			(1 << NUM_ENT_ENTRY_BITS)
#define INVALID_EHANDLE_INDEX	0xFFFFFFFF

#define NUM_SERIAL_NUM_BITS		17 // (32 - NUM_ENT_ENTRY_BITS)
#define NUM_SERIAL_NUM_SHIFT_BITS (32 - NUM_SERIAL_NUM_BITS)
#define ENT_ENTRY_MASK			(( 1 << NUM_SERIAL_NUM_BITS) - 1)


// Networked ehandles use less bits to encode the serial number.
#define NUM_NETWORKED_EHANDLE_SERIAL_NUMBER_BITS	10
#define NUM_NETWORKED_EHANDLE_BITS					(MAX_EDICT_BITS + NUM_NETWORKED_EHANDLE_SERIAL_NUMBER_BITS)
#define INVALID_NETWORKED_EHANDLE_VALUE				((1 << NUM_NETWORKED_EHANDLE_BITS) - 1)

// This is the maximum amount of data a PackedEntity can have. Having a limit allows us
// to use static arrays sometimes instead of allocating memory all over the place.
#define MAX_PACKEDENTITY_DATA	(16384)

// This is the maximum number of properties that can be delta'd. Must be evenly divisible by 8.
#define MAX_PACKEDENTITY_PROPS	(4096)

// a client can have up to 4 customization files (logo, sounds, models, txt).
#define MAX_CUSTOM_FILES		4		// max 4 files
#define MAX_CUSTOM_FILE_SIZE	131072	

//
// Constants shared by the engine and dlls
// This header file included by engine files and DLL files.
// Most came from server.h

// CBaseEntity::m_fFlags
enum Flags_t : uint32
{
	// PLAYER SPECIFIC FLAGS
	FL_ONGROUND 				= (1u << 0), // At rest / on the ground
	FL_DUCKING 					= (1u << 1), // Player flag -- Player is fully crouched
	FL_WATERJUMP 				= (1u << 2), // player jumping out of water
	// FL_EMPTY					= (1u << 3),
	FL_BOT 						= (1u << 4), // Fake client controlled pawn entity, mostly referenced in movement related code
	FL_FROZEN 					= (1u << 5), // Player is frozen for 3rd person camera
	FL_ATCONTROLS 				= (1u << 6), // Player can't move, but keeps key inputs for controlling another entity
	FL_CLIENT 					= (1u << 7), // Is a player
	FL_FAKECLIENT 				= (1u << 8), // Fake client, simulated server side. Mainly set on controllers
	// FL_EMPTY 				= (1u << 9),

	// NON-PLAYER SPECIFIC (i.e., not used by GameMovement or the client .dll ) -- Can still be applied to players, though
	FL_FLY 						= (1u << 10), // Changes the SV_Movestep() behavior to not need to be on ground
	FL_SUPPRESS_SAVE 			= (1u << 11),
	FL_IN_VEHICLE 				= (1u << 12),
	FL_IN_VEHICLE_TRANSPORT 	= (1u << 13),
	FL_GODMODE 					= (1u << 14),
	FL_NOTARGET 				= (1u << 15),
	FL_AIMTARGET 				= (1u << 16), // set if the crosshair needs to aim onto the entity
	// FL_EMPTY 				= (1u << 17),
	FL_STATICPROP 				= (1u << 18), // Eetsa static prop!
	// FL_EMPTY 				= (1u << 19),
	FL_GRENADE 					= (1u << 20),
	// FL_EMPTY					= (1u << 21),
	FL_DONTTOUCH 				= (1u << 22), // Doesn't generate touch functions, generates Untouch() for anything it was touching when this flag was set
	FL_BASEVELOCITY 			= (1u << 23),
	FL_CONVEYOR 				= (1u << 24),
	FL_OBJECT 					= (1u << 25), // Terrible name. This is an object that NPCs should see. Missiles, for example.
	// FL_EMPTY 				= (1u << 26),
	FL_ONFIRE 					= (1u << 27), // You know...
	FL_DISSOLVING 				= (1u << 28), // We're dissolving!
	FL_TRANSRAGDOLL 			= (1u << 29), // In the process of turning into a client side ragdoll.
	FL_UNBLOCKABLE_BY_PLAYER 	= (1u << 30)  // pusher that can't be blocked by the player
	// FL_EMPTY 				= (1u << 31),
};

// edict->movetype values
enum MoveType_t : uint8
{
	MOVETYPE_NONE		= 0,	// never moves
	MOVETYPE_OBSOLETE,			// Previously isometric movetype
	MOVETYPE_WALK,				// Player only - moving on the ground
	MOVETYPE_FLY,				// No gravity, but still collides with stuff
	MOVETYPE_FLYGRAVITY,		// flies through the air + is affected by gravity
	MOVETYPE_VPHYSICS,			// uses VPHYSICS for simulation
	MOVETYPE_PUSH,				// no clip to world, push and crush
	MOVETYPE_NOCLIP,			// No gravity, no collisions, still do velocity/avelocity
	MOVETYPE_OBSERVER,			// Observer movement, depends on player's observer mode
	MOVETYPE_LADDER,			// Used by players only when going onto a ladder
	MOVETYPE_CUSTOM,			// Allows the entity to describe its own physics

	// should always be defined as the last item in the list
	MOVETYPE_LAST,
	MOVETYPE_INVALID	= MOVETYPE_LAST,

	MOVETYPE_MAX_BITS	= 5
};

// edict->movecollide values
enum MoveCollide_t : uint8
{
	MOVECOLLIDE_DEFAULT = 0,

	// These ones only work for MOVETYPE_FLY + MOVETYPE_FLYGRAVITY
	MOVECOLLIDE_FLY_BOUNCE,	// bounces, reflects, based on elasticity of surface and object - applies friction (adjust velocity)
	MOVECOLLIDE_FLY_CUSTOM,	// Touch() will modify the velocity however it likes
	MOVECOLLIDE_FLY_SLIDE,  // slides along surfaces (no bounce) - applies friciton (adjusts velocity)

	MOVECOLLIDE_COUNT,		// Number of different movecollides

	// When adding new movecollide types, make sure this is correct
	MOVECOLLIDE_MAX_BITS = 3
};

// edict->solid values
// NOTE: Some movetypes will cause collisions independent of SOLID_NOT/SOLID_TRIGGER when the entity moves
// SOLID only effects OTHER entities colliding with this one when they move - UGH!

// Solid type basically describes how the bounding volume of the object is represented
// NOTE: SOLID_BBOX MUST BE 2, and SOLID_VPHYSICS MUST BE 6
// NOTE: These numerical values are used in the FGD by the prop code (see prop_dynamic)
enum SolidType_t : uint8
{
	SOLID_NONE			= 0,	// no solid model
	SOLID_BSP			= 1,	// a BSP tree
	SOLID_BBOX			= 2,	// an AABB
	SOLID_OBB			= 3,	// an OBB (not implemented yet)
	SOLID_SPHERE		= 4,
	SOLID_POINT			= 5,
	SOLID_VPHYSICS		= 6,	// solid vphysics object, get vcollide from the model and collide with that
	SOLID_CAPSULE		= 7,
	SOLID_CYLINDER		= 8,
	SOLID_LAST,
};

// GAMMACASE: Potentially obsolete
enum SolidFlags_t
{
	FSOLID_NOT_STANDABLE		= 0x0001,	// You can't stand on this
	FSOLID_USE_TRIGGER_BOUNDS	= 0x0002,	// Uses a special trigger bounds separate from the normal OBB
	FSOLID_NOT_SOLID			= 0x0004,	// Are we currently not solid?

	FSOLID_MAX_BITS	= 3
};

//-----------------------------------------------------------------------------
// A couple of inline helper methods
//-----------------------------------------------------------------------------
inline bool IsSolid( SolidType_t solidType, int nSolidFlags )
{
	return (solidType != SOLID_NONE) && ((nSolidFlags & FSOLID_NOT_SOLID) == 0);
}

// m_lifeState values
enum LifeState_t
{
	LIFE_ALIVE			= 0x0,	// alive
	LIFE_DYING			= 0x1,	// playing death animation or still falling off of a ledge waiting to hit ground
	LIFE_DEAD			= 0x2,	// dead. lying still.
	LIFE_RESPAWNABLE	= 0x3,
	LIFE_RESPAWNING		= 0x4,
	NUM_LIFESTATES
};

// entity effects
enum EntityEffects_t : uint16
{
	// EF_EMPTY				= (1 << 0),
	// EF_EMPTY				= (1 << 1),
	// EF_EMPTY				= (1 << 2),
	DEPRICATED_EF_NOINTERP	= (1 << 3),	// don't interpolate the next frame
	EF_NOSHADOW				= (1 << 4),	// Don't cast no shadow
	EF_NODRAW				= (1 << 5),	// don't draw entity
	EF_NORECEIVESHADOW		= (1 << 6),	// Don't receive no shadow
	// EF_EMPTY				= (1 << 7),
	// EF_EMPTY				= (1 << 8),
	EF_PARENT_ANIMATES		= (1 << 9),
	EF_NODRAW_BUT_TRANSMIT	= (1 << 10),
	EF_MAX_BITS = 10
};

#define EF_PARITY_BITS	3
#define EF_PARITY_MASK  ((1<<EF_PARITY_BITS)-1)

// How many bits does the muzzle flash parity thing get?
#define EF_MUZZLEFLASH_BITS 2

// plats
#define	PLAT_LOW_TRIGGER	1

// Trains
#define	SF_TRAIN_WAIT_RETRIGGER	1
#define SF_TRAIN_PASSABLE		8		// Train is not solid -- used to make water trains

// view angle update types for CPlayerState::fixangle
#define FIXANGLE_NONE			0
#define FIXANGLE_ABSOLUTE		1
#define FIXANGLE_RELATIVE		2

// Break Model Defines

#define BREAK_GLASS		0x01
#define BREAK_METAL		0x02
#define BREAK_FLESH		0x04
#define BREAK_WOOD		0x08

#define BREAK_SMOKE		0x10
#define BREAK_TRANS		0x20
#define BREAK_CONCRETE	0x40

// If this is set, then we share a lighting origin with the last non-slave breakable sent down to the client
#define BREAK_SLAVE		0x80

// Colliding temp entity sounds

#define BOUNCE_GLASS	BREAK_GLASS
#define	BOUNCE_METAL	BREAK_METAL
#define BOUNCE_FLESH	BREAK_FLESH
#define BOUNCE_WOOD		BREAK_WOOD
#define BOUNCE_SHRAP	0x10
#define BOUNCE_SHELL	0x20
#define	BOUNCE_CONCRETE BREAK_CONCRETE
#define BOUNCE_SHOTSHELL 0x80

// Temp entity bounce sound types
#define TE_BOUNCE_NULL		0
#define TE_BOUNCE_SHELL		1
#define TE_BOUNCE_SHOTSHELL	2

// Rendering constants
// if this is changed, update common/MaterialSystem/Sprite.cpp
enum RenderMode_t : unsigned char
{	
	kRenderNormal = 0,		// src
	kRenderTransAlpha,		// src*srca+dest*(1-srca)
	kRenderNone,			// Don't render.

	kRenderModeCount,		// must be last
};

enum RenderFx_t : unsigned char
{	
	kRenderFxNone = 0, 
	kRenderFxPulseSlow, 
	kRenderFxPulseFast, 
	kRenderFxPulseSlowWide, 
	kRenderFxPulseFastWide, 

	kRenderFxFadeSlow, 
	kRenderFxFadeFast, 
	kRenderFxSolidSlow, 
	kRenderFxSolidFast, 	   
	kRenderFxStrobeSlow, 

	kRenderFxStrobeFast, 
	kRenderFxStrobeFaster, 
	kRenderFxFlickerSlow, 
	kRenderFxFlickerFast,

	kRenderFxFadeOut,
	kRenderFxFadeIn,
	kRenderFxPulseFastWider,

	kRenderFxMax
};

typedef uint32 SpawnGroupHandle_t;

enum ESpawnGroupUnloadOption
{
	kSGUO_None = 0,
	kSGUO_SaveEntities,
	kSGUO_MergedIntoOwner,
};

enum BuiltInInteractionLayer_t
{
	LAYER_INDEX_CONTENTS_SOLID = 0,
	LAYER_INDEX_CONTENTS_HITBOX,
	LAYER_INDEX_CONTENTS_TRIGGER,
	LAYER_INDEX_CONTENTS_SKY,
	LAYER_INDEX_FIRST_USER,
	LAYER_INDEX_NOT_FOUND = -1,
	LAYER_INDEX_MAX_ALLOWED = 64,
};

enum StandardInteractionLayers_t
{
	LAYER_INDEX_CONTENTS_PLAYER_CLIP = LAYER_INDEX_FIRST_USER,
	LAYER_INDEX_CONTENTS_NPC_CLIP,
	LAYER_INDEX_CONTENTS_BLOCK_LOS,
	LAYER_INDEX_CONTENTS_BLOCK_LIGHT,
	LAYER_INDEX_CONTENTS_LADDER,
	LAYER_INDEX_CONTENTS_PICKUP,
	LAYER_INDEX_CONTENTS_BLOCK_SOUND,
	LAYER_INDEX_CONTENTS_NODRAW,
	LAYER_INDEX_CONTENTS_WINDOW,
	LAYER_INDEX_CONTENTS_PASS_BULLETS,
	LAYER_INDEX_CONTENTS_WORLD_GEOMETRY,
	LAYER_INDEX_CONTENTS_WATER,
	LAYER_INDEX_CONTENTS_SLIME,
	LAYER_INDEX_CONTENTS_TOUCH_ALL,
	LAYER_INDEX_CONTENTS_PLAYER,
	LAYER_INDEX_CONTENTS_NPC,
	LAYER_INDEX_CONTENTS_DEBRIS,
	LAYER_INDEX_CONTENTS_PHYSICS_PROP,
	LAYER_INDEX_CONTENTS_NAV_IGNORE,
	LAYER_INDEX_CONTENTS_NAV_LOCAL_IGNORE,
	LAYER_INDEX_CONTENTS_POST_PROCESSING_VOLUME,
	LAYER_INDEX_CONTENTS_VEHICLE_CLIP,
	LAYER_INDEX_CONTENTS_CARRIED_OBJECT,
	LAYER_INDEX_CONTENTS_PUSHAWAY,
	LAYER_INDEX_CONTENTS_SERVER_ENTITY_ON_CLIENT,
	LAYER_INDEX_CONTENTS_CARRIED_WEAPON,
	LAYER_INDEX_CONTENTS_STATIC_LEVEL,
	LAYER_INDEX_FIRST_MOD_SPECIFIC,
};

enum ModSpecificInteractionLayers_t
{
	LAYER_INDEX_CONTENTS_CSGO_TEAM1 = LAYER_INDEX_FIRST_MOD_SPECIFIC,
	LAYER_INDEX_CONTENTS_CSGO_TEAM2,
	LAYER_INDEX_CONTENTS_CSGO_GRENADE_CLIP,
	LAYER_INDEX_CONTENTS_CSGO_DRONE_CLIP,
	LAYER_INDEX_CONTENTS_CSGO_MOVEABLE,
	LAYER_INDEX_CONTENTS_CSGO_OPAQUE,
	LAYER_INDEX_CONTENTS_CSGO_MONSTER,
	LAYER_INDEX_CONTENTS_CSGO_UNUSED_LAYER,
	LAYER_INDEX_CONTENTS_CSGO_THROWN_GRENADE,
};

enum BuiltInCollisionGroup_t
{
	// Default layer, always collides with everything.
	COLLISION_GROUP_ALWAYS = 0, // "always"
	// This is how you turn off all collisions for an object - move it to this group
	COLLISION_GROUP_NONPHYSICAL, // "never" 
	// Trigger layer, never collides with anything, only triggers/interacts.  Use when querying for interaction layers.
	COLLISION_GROUP_TRIGGER, // "trigger"
	// Conditionally solid means that the collision response will be zero or as defined in the table when there are matching interactions
	COLLISION_GROUP_CONDITIONALLY_SOLID, // needs interactions
	// First unreserved collision layer index.
	COLLISION_GROUP_FIRST_USER,
	// Hard limit of 254 due to memory layout, and these are never visible to scene queries.
	COLLISION_GROUPS_MAX_ALLOWED = 64,
};

enum StandardCollisionGroups_t
{
	COLLISION_GROUP_DEFAULT = COLLISION_GROUP_FIRST_USER,
	COLLISION_GROUP_DEBRIS,			// Collides with nothing but world, static stuff and triggers
	COLLISION_GROUP_INTERACTIVE_DEBRIS,	// Collides with everything except other interactive debris or debris
	COLLISION_GROUP_INTERACTIVE,	// Collides with everything except interactive debris or debris
	COLLISION_GROUP_PLAYER,
	COLLISION_GROUP_BREAKABLE_GLASS,
	COLLISION_GROUP_VEHICLE,
	COLLISION_GROUP_PLAYER_MOVEMENT,  // For HL2, same as Collision_Group_Player, for
										// TF2, this filters out other players and CBaseObjects
	COLLISION_GROUP_NPC,			// Generic NPC group
	COLLISION_GROUP_IN_VEHICLE,		// for any entity inside a vehicle
	COLLISION_GROUP_WEAPON,			// for any weapons that need collision detection
	COLLISION_GROUP_VEHICLE_CLIP,	// vehicle clip brush to restrict vehicle movement
	COLLISION_GROUP_PROJECTILE,		// Projectiles!
	COLLISION_GROUP_DOOR_BLOCKER,	// Blocks entities not permitted to get near moving doors
	COLLISION_GROUP_PASSABLE_DOOR,	// Doors that the player shouldn't collide with
	COLLISION_GROUP_DISSOLVING,		// Things that are dissolving are in this group
	COLLISION_GROUP_PUSHAWAY,		// Nonsolid on client and server, pushaway in player code

	COLLISION_GROUP_NPC_ACTOR,		// Used so NPCs in scripts ignore the player.
	COLLISION_GROUP_NPC_SCRIPTED,	// Used for NPCs in scripts that should not collide with each other
	COLLISION_GROUP_PZ_CLIP,
	COLLISION_GROUP_PROPS,

	LAST_SHARED_COLLISION_GROUP,
};

#include "basetypes.h"

#define SOUND_NORMAL_CLIP_DIST	1000.0f

//-----------------------------------------------------------------------------
// Base light indices to avoid index collision
//-----------------------------------------------------------------------------

enum
{
	LIGHT_INDEX_TE_DYNAMIC = 0x10000000,
	LIGHT_INDEX_PLAYER_BRIGHT = 0x20000000,
	LIGHT_INDEX_MUZZLEFLASH = 0x40000000,
	LIGHT_INDEX_LOW_PRIORITY = 0x64000000,
};

// How many networked area portals do we allow?
#define MAX_AREA_STATE_BYTES		32
#define MAX_AREA_PORTAL_STATE_BYTES 24

// user message max payload size (note, this value is used by the engine, so MODs cannot change it)
#define MAX_USER_MSG_BITS 12
#define MAX_USER_MSG_DATA ( ( 1 << ( MAX_USER_MSG_BITS - 3 ) ) - 1 )
#define MAX_ENTITY_MSG_DATA 255

#define SOURCE_MT
#ifdef SOURCE_MT
class CAtomicMutex;
typedef CAtomicMutex CSourceMutex;
#else
class CThreadNullMutex;
typedef CThreadNullMutex CSourceMutex;
#endif

#if defined( CLIENT_DLL )
#define IsServerDll() false
#define IsClientDll() true
#elif defined( GAME_DLL )
#define IsServerDll() true
#define IsClientDll() false
#else
#define IsServerDll() false
#define IsClientDll() false
#endif

#endif

